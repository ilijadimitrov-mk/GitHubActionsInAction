namespace unittests
{
    [TestClass]
    public class Fast_Unit_Tests
    {
        [TestMethod("validate numbers are > 0")]
        public void numbers_are_greater_then_0()
        {
            Assert.IsTrue(true);
        }
        [TestMethod("validate numbers are < 10")]
        public void numbers_are_greater_smaller_than_10()
        {
            Assert.IsTrue(true);
        }
        [TestMethod("validate numbers are odd")]
        public void numbers_are_odd()
        {
            Assert.IsTrue(true);
        }
        [TestMethod("validate numbers are even")]
        public void numbers_are_even()
        {
            Assert.IsTrue(true);
        }
    }
}
