﻿namespace Tests.Playwright.PageObjects
{
    internal class CustomerNico
    {
        public string email = "norschel@xpirit.com";
        public string name = "Nico Orschel";
        public string street = "Irgendwo in Eschborn";
        public string town = "Eschborn";
        public string postalcode = "60606";
        public string cc = "4303651055386607";
        public string expdate = "09/28";

    }
}